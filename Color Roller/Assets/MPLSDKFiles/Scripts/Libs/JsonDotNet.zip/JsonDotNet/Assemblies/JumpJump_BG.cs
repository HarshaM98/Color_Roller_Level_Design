﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class JumpJump_BG : MonoBehaviour {

   // public Material mat;
   // Color topColor,bottomColor;
    //public InputField topColorTxt, bottomColorTxt;

    void Start()
    {

        // col= Color.HSVToRGB(Random.Range(0,360)/360.0f, 85.0f/100.0f, 100.0f/100.0f);
        // mat.shader = Shader.Find("Custom/Gradient");

        // Debug.Log(mat.GetColor("_Color1"));
    }

   /* public void UpdateBG()
    {
        ColorUtility.TryParseHtmlString("#"+topColorTxt.text, out topColor);
        ColorUtility.TryParseHtmlString("#"+bottomColorTxt.text, out bottomColor);
        Debug.Log(topColor);
        mat.SetColor("_Color1", bottomColor);
        mat.SetColor("_Color2", topColor);
    }*/


}
